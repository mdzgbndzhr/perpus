<?php
session_start();
$koneksi = Mysqli_connect('localhost', 'root', '', 'ukk_perpus');
